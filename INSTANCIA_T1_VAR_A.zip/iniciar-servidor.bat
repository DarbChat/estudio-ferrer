@echo off
cd /d "%~dp0"
echo Servidor de Estudio Ferrer en marcha. Abre en el navegador: http://127.0.0.1:8080/
echo Para detenerlo, cierra esta ventana o pulsa Ctrl+C.
where py >nul 2>nul
if %errorlevel%==0 (py harness_server.py site 8080) else (python harness_server.py site 8080)
pause
