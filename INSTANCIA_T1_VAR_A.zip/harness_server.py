#!/usr/bin/env python3
# harness_server.py - servidor de referencia para las pruebas (NO forma parte de V7 ni V3)
# Uso: python3 harness_server.py <directorio> <puerto> [prefijo] [puerto_mock]
import http.server, os, sys, json, time, mimetypes, threading

ROOT = os.path.abspath(sys.argv[1])
PORT = int(sys.argv[2])
PREFIX = sys.argv[3].rstrip("/") if len(sys.argv) > 3 else ""
MOCK_PORT = int(sys.argv[4]) if len(sys.argv) > 4 else 8099
LOGF = os.environ.get("HARNESS_LOG", "harness_access.log")
AFTER = os.environ.get("AFTER_SUBMISSION", "http://127.0.0.1:%d%s/contacto/gracias/" % (PORT, PREFIX))

def log(rec):
    rec["t"] = time.time()
    with open(LOGF, "a") as f:
        f.write(json.dumps(rec) + "\n")

class Static(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def reply(self, status, fpath):
        body, ctype = b"Not found", "text/plain"
        if fpath and os.path.isfile(fpath):
            with open(fpath, "rb") as f: body = f.read()
            ctype = mimetypes.guess_type(fpath)[0] or "application/octet-stream"
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)
        log({"m": "GET", "p": self.path, "s": status})
    def do_GET(self):
        raw = self.path.split("?")[0].split("#")[0]
        if PREFIX:
            if raw != PREFIX and not raw.startswith(PREFIX + "/"):
                return self.reply(404, os.path.join(ROOT, "404.html"))
            raw = raw[len(PREFIX):] or "/"
        full = os.path.normpath(os.path.join(ROOT, raw.lstrip("/")))
        if not full.startswith(ROOT):
            return self.reply(404, None)
        if os.path.isdir(full):
            if not raw.endswith("/"):
                self.send_response(301)
                self.send_header("Location", PREFIX + raw + "/")
                self.send_header("Content-Length", "0")
                self.end_headers()
                log({"m": "GET", "p": self.path, "s": 301})
                return
            full = os.path.join(full, "index.html")
        if os.path.isfile(full):
            return self.reply(200, full)
        return self.reply(404, os.path.join(ROOT, "404.html"))

class Mock(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(n).decode("utf-8", "replace")
        log({"m": "POST", "p": self.path, "body": body})
        self.send_response(303)
        self.send_header("Location", AFTER)
        self.send_header("Content-Length", "0")
        self.end_headers()

if __name__ == "__main__":
    threading.Thread(target=http.server.HTTPServer(("127.0.0.1", MOCK_PORT), Mock).serve_forever, daemon=True).start()
    http.server.HTTPServer(("127.0.0.1", PORT), Static).serve_forever()
